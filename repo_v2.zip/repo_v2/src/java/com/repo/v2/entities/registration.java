
package com.repo.v2.entities;
import java.sql.*;

public class registration {
     private String firstname ;
     private String lastname;
     private String emailid;
     private String password;

     
     //constructor
    public registration(String firstname, String lastname, String emailid, String password) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.emailid = emailid;
        this.password = password;
    }

    public registration() {}

    
    //getter and setter method
    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getEmailid() {
        return emailid;
    }

    public void setEmailid(String emailid) {
        this.emailid = emailid;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

   
 }
