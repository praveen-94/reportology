
package com.repo.v2.dao;
import com.repo.v2.entities.registration;
import java.sql.*;

public class userdao {
    private Connection con;

    public userdao(Connection con) {
        this.con = con;
    }
    
    //method to insert user to data base
    public boolean saveUser( registration user)
    {   
        boolean f=false;
        try{
            //user data
            String query="insert into registration(firstname,lastname,emailid,password) values(?,?,?,?)";
            PreparedStatement pstmt = this.con.prepareStatement(query);
            pstmt.setString(1, user.getFirstname());
            pstmt.setString(2, user.getLastname());
            pstmt.setString(3, user.getEmailid());
            pstmt.setString(4, user.getPassword());
            
            pstmt.executeUpdate();
            f=true;
        }
        catch(Exception e)
        { e.printStackTrace();
        }
        return f;
    }
    
    //get user by email and password
    public registration getinf(String emailid, String password)
    {  registration user=null;
        try{ 
            String query="select * from user where emailid=? and password=?";
            PreparedStatement pstmt=con.prepareStatement(query);
            pstmt.setString(1, emailid);
            pstmt.setString(2, password);
            
            ResultSet set=pstmt.executeQuery();
            
            if(set.next())
            { user =new registration();
              String firstname=set.getString("firstname");
              user.setFirstname(firstname);
              user.setLastname(set.getString("lastname"));
              user.setEmailid(set.getString("emailid"));
              user.setPassword(set.getString("password"));
              
            }
            
        }catch(Exception e)
                  {
                      e.printStackTrace();    
                  }
    
        return user;
}

}